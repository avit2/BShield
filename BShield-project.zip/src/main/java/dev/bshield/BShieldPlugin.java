package dev.bshield;

import dev.bshield.command.BShieldCommand;
import dev.bshield.geyser.GeyserHook;
import dev.bshield.item.BShieldItems;
import dev.bshield.listener.ShieldProtectionListener;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.plugin.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class BShieldPlugin extends JavaPlugin {

    private static final String GEYSER_PLUGIN_NAME = "Geyser-Spigot";

    private GeyserHook geyserHook;

    @Override
    public void onEnable() {
        BShieldItems.init(this);
        registerRecipe();
        registerCommand();
        getServer().getPluginManager().registerEvents(new ShieldProtectionListener(this), this);
        hookGeyser();
    }

    @Override
    public void onDisable() {
        if (geyserHook != null) {
            try {
                geyserHook.unregister();
            } catch (Throwable t) {
                getLogger().warning("Geyser unregister failed: " + t.getMessage());
            }
            geyserHook = null;
        }
    }

    private void registerRecipe() {
        ItemStack result = BShieldItems.create();
        NamespacedKey key = new NamespacedKey(this, "bshield");
        try {
            getServer().removeRecipe(key);
        } catch (Throwable ignored) {}
        ShapedRecipe recipe = new ShapedRecipe(key, result);
        recipe.shape("IWI", "WWW", " W ");
        recipe.setIngredient('I', Material.IRON_INGOT);
        recipe.setIngredient('W', Material.OAK_PLANKS);
        boolean added = getServer().addRecipe(recipe);
        if (!added) {
            getLogger().warning("BShield recipe eklenemedi (key: " + key + ").");
        }
    }

    private void registerCommand() {
        PluginCommand command = getCommand("bshield");
        if (command == null) {
            getLogger().warning("/bshield komutu plugin.yml icinde tanimli degil.");
            return;
        }
        BShieldCommand executor = new BShieldCommand(this);
        command.setExecutor(executor);
        command.setTabCompleter(executor);
    }

    private void hookGeyser() {
        var pm = Bukkit.getPluginManager();
        if (pm.getPlugin(GEYSER_PLUGIN_NAME) == null) {
            getLogger().warning("Geyser-Spigot bulunamadi. Bedrock oyuncular BShield'i SPYGLASS olarak gorebilir.");
            return;
        }
        try {
            geyserHook = new GeyserHook(this);
            geyserHook.register();
            getLogger().info("Geyser Custom Items API v2 hook registered.");
        } catch (Throwable t) {
            getLogger().warning("Geyser hook basarisiz: " + t.getMessage());
            geyserHook = null;
        }
    }

}
