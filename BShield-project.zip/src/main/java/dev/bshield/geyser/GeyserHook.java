package dev.bshield.geyser;

import org.bukkit.plugin.Plugin;
import org.geysermc.geyser.api.GeyserApi;
import org.geysermc.geyser.api.event.EventRegistrar;
import org.geysermc.geyser.api.event.lifecycle.GeyserDefineCustomItemsEvent;
import org.geysermc.geyser.api.item.custom.CustomItemBedrockOptions;
import org.geysermc.geyser.api.item.custom.CustomItemDefinition;
import org.geysermc.geyser.api.util.Identifier;

public final class GeyserHook implements EventRegistrar {

    private static final Identifier JAVA_ID    = Identifier.of("minecraft:spyglass");
    private static final Identifier BEDROCK_ID = Identifier.of("bshield:shield");
    private static final Identifier MODEL_ID   = Identifier.of("bshield:shield");

    private final Plugin plugin;
    private boolean registered = false;

    public GeyserHook(Plugin plugin) {
        this.plugin = plugin;
    }

    public void register() {
        GeyserApi.api().eventBus().register(
            this,
            GeyserDefineCustomItemsEvent.class,
            this::onDefineCustomItems
        );
        registered = true;
    }

    public void unregister() {
        if (!registered) return;
        try {
            GeyserApi.api().eventBus().unregisterAll(this);
        } catch (Throwable t) {
            plugin.getLogger().warning("Geyser unregister failed: " + t.getMessage());
        }
        registered = false;
    }

    private void onDefineCustomItems(GeyserDefineCustomItemsEvent event) {
        CustomItemBedrockOptions options = CustomItemBedrockOptions.builder()
            .displayHandheld(true)
            .icon("bshield_shield")
            .build();

        CustomItemDefinition definition = CustomItemDefinition.builder(BEDROCK_ID, MODEL_ID)
            .displayName("BShield")
            .bedrockOptions(options)
            .build();

        event.register(JAVA_ID, definition);

        plugin.getLogger().info("Registered Geyser custom item: bshield:shield -> minecraft:spyglass");
    }

}
