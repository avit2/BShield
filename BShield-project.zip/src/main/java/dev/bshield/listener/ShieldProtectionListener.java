package dev.bshield.listener;

import dev.bshield.BShieldPlugin;
import org.bukkit.event.Listener;

/**
 * BShield icin native Paper data component'leri (BLOCKS_ATTACKS, CONSUMABLE,
 * USE_ANIMATION, MAX_DAMAGE) tum bloklama/kullanim/dayaniklilik davranisini saglar.
 *
 * Bu sinif kasitli olarak BOS bir Listener'dir:
 * - EntityDamageEvent ile sahte shield sistemi YOKTUR.
 * - Hasar iptali/azaltimi YOKTUR.
 * - Vanilla Material.SHIELD davranisina mudahale YOKTUR.
 * - PlayerItemDamageEvent / PrepareItemCraftEvent gibi no-op dinleyiciler YOKTUR.
 *
 * Sinif, BShieldPlugin tarafindan registerEvents ile olusturuldugu icin
 * (BShieldPlugin degistirilmeden) geriye uyumluluk amaciyla korunmustur.
 * Ileride BShieldPlugin'deki registerEvents cagrisi kaldirilirsa bu sinif
 * tamamen silinebilir.
 */
public final class ShieldProtectionListener implements Listener {

    @SuppressWarnings("unused")
    private final BShieldPlugin plugin;

    public ShieldProtectionListener(BShieldPlugin plugin) {
        this.plugin = plugin;
    }

    // Bilerek hicbir @EventHandler metodu yok.
    // Native BLOCKS_ATTACKS + CONSUMABLE + USE_ANIMATION yeterlidir.
}
