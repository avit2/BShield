package dev.bshield.item;

import io.papermc.paper.datacomponent.DataComponentTypes;
import io.papermc.paper.datacomponent.item.Consumable;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ItemUseAnimation;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public final class BShieldItems {

    public static final String NAMESPACE = "bshield";
    public static final String ITEM_KEY  = "shield";
    public static final String PDC_KEY   = "item";
    public static final String PDC_VALUE = "shield";

    private static NamespacedKey pdcItemKey;
    private static NamespacedKey modelKey;

    private BShieldItems() {}

    public static void init(Plugin plugin) {
        pdcItemKey = new NamespacedKey(NAMESPACE, PDC_KEY);
        modelKey   = new NamespacedKey(NAMESPACE, ITEM_KEY);
    }

    public static NamespacedKey pdcItemKey() {
        return pdcItemKey;
    }

    public static ItemStack create() {
        ItemStack stack = new ItemStack(Material.SPYGLASS);

        ItemMeta meta = stack.getItemMeta();
        meta.displayName(
            Component.text("BShield", NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false)
        );
        meta.getPersistentDataContainer().set(
            pdcItemKey,
            PersistentDataType.STRING,
            PDC_VALUE
        );
        stack.setItemMeta(meta);

        stack.setData(DataComponentTypes.MAX_DAMAGE, 336);
        stack.setData(DataComponentTypes.MAX_STACK_SIZE, 1);
        stack.setData(DataComponentTypes.ITEM_MODEL, modelKey);
        stack.setData(DataComponentTypes.USE_ANIMATION, ItemUseAnimation.BLOCK);

        Consumable consumable = Consumable.consumable()
            .animation(ItemUseAnimation.BLOCK)
            .consumeSeconds(3600.0f)
            .hasConsumeParticles(false)
            .build();
        stack.setData(DataComponentTypes.CONSUMABLE, consumable);

        ItemStack vanillaShield = new ItemStack(Material.SHIELD);
        var blocksAttacks = vanillaShield.getData(DataComponentTypes.BLOCKS_ATTACKS);
        if (blocksAttacks != null) {
            stack.setData(DataComponentTypes.BLOCKS_ATTACKS, blocksAttacks);
        }

        return stack;
    }

    public static boolean isBShield(ItemStack stack) {
        if (stack == null || stack.getType() != Material.SPYGLASS) return false;
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return false;
        String v = meta.getPersistentDataContainer().get(pdcItemKey, PersistentDataType.STRING);
        return PDC_VALUE.equals(v);
    }

}
