package dev.bshield.command;

import dev.bshield.BShieldPlugin;
import dev.bshield.item.BShieldItems;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class BShieldCommand implements CommandExecutor, TabCompleter {

    private static final String PERMISSION = "bedrockshields.admin";

    @SuppressWarnings("unused")
    private final BShieldPlugin plugin;

    public BShieldCommand(BShieldPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission(PERMISSION)) {
            sender.sendMessage(Component.text("Bu komut icin yetkin yok.", NamedTextColor.RED));
            return true;
        }

        if (args.length == 0) {
            sendUsage(sender, label);
            return true;
        }

        if (!args[0].equalsIgnoreCase("give")) {
            sendUsage(sender, label);
            return true;
        }

        if (args.length < 2) {
            sendUsage(sender, label);
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(
                Component.text("Oyuncu bulunamadi: ", NamedTextColor.RED)
                    .append(Component.text(args[1], NamedTextColor.WHITE))
            );
            return true;
        }

        ItemStack shield = BShieldItems.create();
        var leftover = target.getInventory().addItem(shield);
        for (ItemStack drop : leftover.values()) {
            target.getWorld().dropItemNaturally(target.getLocation(), drop);
        }

        sender.sendMessage(
            Component.text("BShield verildi: ", NamedTextColor.GREEN)
                .append(Component.text(target.getName(), NamedTextColor.WHITE))
        );
        target.sendMessage(Component.text("Bir BShield aldin.", NamedTextColor.AQUA));
        return true;
    }

    private void sendUsage(CommandSender sender, String label) {
        sender.sendMessage(
            Component.text("Kullanim: /" + label + " give <player>", NamedTextColor.YELLOW)
        );
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender,
                                                @NotNull Command command,
                                                @NotNull String label,
                                                @NotNull String[] args) {
        if (!sender.hasPermission(PERMISSION)) return List.of();

        if (args.length == 1) {
            return filter(List.of("give"), args[0]);
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            List<String> names = new ArrayList<>();
            for (Player p : Bukkit.getOnlinePlayers()) names.add(p.getName());
            return filter(names, args[1]);
        }

        return List.of();
    }

    private List<String> filter(List<String> options, String prefix) {
        if (prefix == null || prefix.isEmpty()) return options;
        String p = prefix.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String s : options) {
            if (s.toLowerCase(Locale.ROOT).startsWith(p)) out.add(s);
        }
        return out;
    }

}
