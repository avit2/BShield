BShield
Bedrock oyuncuları için özel kalkan (shield) sağlayan Paper eklentisi.
Özellikler
Java oyuncuları için vanilla SHIELD hiç değiştirilmez.
Bedrock oyuncuları için Geyser Custom Items API v2 üzerinden özel bshield:shield tanımlanır.
Bloklama mekanizması Paper'ın native BLOCKS_ATTACKS data component'i ile sağlanır (timer/fake damage yok).
Craft tarifi vanilla kalkandan farklıdır:
I W I
W W W
  W
(I = IRON_INGOT, W = OAK_PLANKS)
Gereksinimler
Paper 26.2+ (veya uyumlu)
Java 25
Geyser-Spigot 2.11.1+
Floodgate (opsiyonel)
Geyser Yapılandırması
config.yml içinde:
gameplay:
  enable-custom-content: true
add-non-bedrock-items varsayılan true kalabilir.
Resource Pack
resource-pack/ klasörünün içeriğini Bedrock resource pack olarak paketle.
PNG'ler:
python3 resource-pack/generate_textures.py
Pillow gerekir.
Komutlar
/bshield give <player>
Yetki:
bedrockshields.admin
Derleme
gradle build
Çıktı:
build/libs/BShield-1.0.0.jar
GitHub Actions
.github/workflows/build.yml push/PR/manual tetikleme ile JAR üretir ve artifact olarak yükler.
