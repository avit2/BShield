plugins {
    java
    id("com.gradleup.shadow") version "9.4.1"
}

group = "dev.bshield"
version = providers.gradleProperty("pluginVersion").get()

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
    maven("https://repo.opencollab.dev/main/")
    maven("https://repo.opencollab.dev/maven-snapshots/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:${providers.gradleProperty("paperApiVersion").get()}")
    compileOnly("org.geysermc.geyser:api:${providers.gradleProperty("geyserApiVersion").get()}")
    compileOnly("org.geysermc.floodgate:api:${providers.gradleProperty("floodgateApiVersion").get()}")
}

java {
    toolchain.languageVersion.set(
        JavaLanguageVersion.of(providers.gradleProperty("javaVersion").get().toInt())
    )
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release.set(providers.gradleProperty("javaVersion").get().toInt())
}

tasks.processResources {
    val props = mapOf("version" to project.version.toString())
    inputs.properties(props)
    filesMatching("plugin.yml") {
        expand(props)
    }
}

tasks.jar {
    archiveClassifier.set("plain")
}

tasks.shadowJar {
    archiveClassifier.set("")
    minimize()
}

tasks.build {
    dependsOn(tasks.shadowJar)
}
