#!/usr/bin/env python3
import os
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
BODY_FILL = (95, 135, 205, 255)
BODY_EDGE = (22, 42, 82, 255)
BOSS_FILL = (240, 220, 120, 255)
BOSS_EDGE = (120, 90, 20, 255)
HANDLE_FILL = (125, 85, 45, 255)
HANDLE_EDGE = (60, 40, 20, 255)
ICON_BG = (20, 30, 60, 255)


def save(img: Image.Image, *rel: str) -> None:
    p = os.path.join(HERE, *rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p, "PNG")
    print(f"wrote {p}  ({img.size[0]}x{img.size[1]})")


def make_item_icon() -> Image.Image:
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rectangle([3, 1, 12, 14], fill=BODY_FILL, outline=BODY_EDGE)
    d.rectangle([6, 6, 9, 9], fill=BOSS_FILL, outline=BOSS_EDGE)
    d.line([(4, 2), (11, 2)], fill=(200, 220, 255, 255))
    d.line([(7, 14), (8, 14)], fill=HANDLE_FILL)
    return img


def make_entity_texture() -> Image.Image:
    img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, 15, 18], fill=BODY_FILL, outline=BODY_EDGE)
    d.line([(1, 1), (14, 1)], fill=(200, 220, 255, 255))
    d.line([(7, 2), (7, 17)], fill=(70, 105, 170, 255))
    d.line([(8, 2), (8, 17)], fill=(70, 105, 170, 255))
    d.rectangle([0, 19, 13, 26], fill=BOSS_FILL, outline=BOSS_EDGE)
    d.line([(1, 20), (12, 20)], fill=(255, 245, 190, 255))
    d.line([(1, 25), (12, 25)], fill=(180, 150, 60, 255))
    d.rectangle([12, 19, 21, 28], fill=HANDLE_FILL, outline=HANDLE_EDGE)
    d.point((14, 22), fill=(30, 20, 10, 255))
    d.point((19, 22), fill=(30, 20, 10, 255))
    d.point((14, 25), fill=(30, 20, 10, 255))
    d.point((19, 25), fill=(30, 20, 10, 255))
    return img


def make_pack_icon() -> Image.Image:
    img = Image.new("RGBA", (128, 128), ICON_BG)
    d = ImageDraw.Draw(img)
    d.polygon(
        [(24, 16), (104, 16), (104, 88), (64, 116), (24, 88)],
        fill=BODY_FILL,
        outline=(240, 240, 240, 255),
    )
    d.line([(30, 22), (98, 22)], fill=(200, 220, 255, 255), width=3)
    d.ellipse([48, 48, 80, 80], fill=BOSS_FILL, outline=BOSS_EDGE, width=3)
    d.ellipse([56, 56, 72, 72], fill=(255, 245, 190, 255), outline=BOSS_EDGE)
    d.rectangle([60, 88, 68, 116], fill=HANDLE_FILL, outline=HANDLE_EDGE, width=2)
    return img


def main() -> None:
    save(make_item_icon(), "textures", "items", "bshield_shield.png")
    save(make_entity_texture(), "textures", "entity", "bshield_shield.png")
    save(make_pack_icon(), "pack_icon.png")
    print("Done.")


if __name__ == "__main__":
    main()
